#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum = 0;

    printf("Enter any number:");
    scanf("%d", &n); // n = 121

    while(n > 0)
    //for(;n > 0;)
    {
        r = n % 10; // 1, 2, 1
        sum = sum + r; // sum = 1, 12, 121
        n = n / 10; // 121 / 10 = 12, 1, 0
    }

    printf("Sum of Digits is: %d", sum);

    return 0;
}
