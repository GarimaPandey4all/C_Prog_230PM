#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, fact = 1;

    printf("Enter any number that you want to print the factorial:");
    scanf("%d", &n);

    for(int i = 1; i <= n; i++)
    {
        fact *= i; //fact = fact * i;
    }

    printf("Factorial of %d is = %d", n, fact);

    return 0;
}
