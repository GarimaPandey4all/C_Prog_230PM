#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, reverse = 0;

    printf("Enter any number:");
    scanf("%d", &n); // n = 121

    while(n > 0)
    //for(;n > 0;)
    {
        r = n % 10; // 1, 2, 1
        reverse = reverse * 10 + r; // sum = 1, 12, 121
        n = n / 10; // 121 / 10 = 12, 1, 0
    }

    printf("Reverse Number is: %d", reverse);

    return 0;
}
