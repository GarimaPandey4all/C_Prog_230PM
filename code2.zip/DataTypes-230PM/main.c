#include <stdio.h>
#include <stdlib.h>

int main()
{
    // 1 byte = 8 bits

    int a = 10; // 4 bytes
    float b = 34.56f; // 4 bytes
    char ch = 'A'; // 1 byte
    double d = 45.67; // 8 bytes

    printf("A is: %d\n", a);
    printf("B is: %.2f\n", b);
    printf("Ch is: %c\n", ch);
    printf("D is: %lf\n", d);

    printf("size of A is: %d\n", sizeof(a));
    printf("size of A is: %d\n", sizeof(int));
    printf("size of B is: %d\n", sizeof(b));
    printf("size of Ch is: %d\n", sizeof(ch));
    printf("size of D is: %d\n", sizeof(d));

    return 0;
}
