#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10; // assignment / initialization
    const float PI = 3.14; // floating point numbers
    int r = 10;

    //const - fixed the value

    //PI = 34.56; // error

    printf("A is: %d\n", a); // \n - new line character or Enter

    a = 20; // re-initialization

    printf("A is: %d\n", a);

    printf("Area of Circle is: %.2f", (PI * r * r));

    return 0;
}
