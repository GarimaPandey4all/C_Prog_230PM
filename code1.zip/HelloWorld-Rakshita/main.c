#include <stdio.h>
#include <stdlib.h>

int main()
{
    //clrscr();
    printf("Hello world!\n");
    getch();
    return 0;
}
