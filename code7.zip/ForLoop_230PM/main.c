#include <stdio.h>
#include <stdlib.h>

/*
    Loops: Repeat or Iteration

    1. For Loop
    2. While Loop
    3. Do-While Loop

*/

int main()
{
    int i, n;

    printf("Enter any number:");
    scanf("%d", &n);

    for(i = 1; i <= 10; i++)
    {
        //printf("Hello World\n");
        printf("%d * %d = %d\n", n, i, n * i);
    }

    return 0;
}
