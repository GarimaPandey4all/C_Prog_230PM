#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, temp;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

//    printf("Before Swapping the value of a=%d and b=%d\n", a, b);
//
//    //First-Way
//
//    a = a ^ b;
//    b = a ^ b;
//    a = a ^ b;
//
//    printf("After Swapping the value of a=%d and b=%d\n", a, b);

//    printf("Before Swapping the value of a=%d and b=%d\n", a, b);
//
//    //Second-Way
//
//    a = a + b; // 9
//    b = a - b; // 4
//    a = a - b; // 5
//
//    printf("After Swapping the value of a=%d and b=%d\n", a, b);

    printf("Before Swapping the value of a=%d and b=%d\n", a, b);

    //Third-Way

    a = a * b; // 20
    b = a / b; // 4
    a = a / b; // 5

    printf("After Swapping the value of a=%d and b=%d\n", a, b);

    return 0;
}
