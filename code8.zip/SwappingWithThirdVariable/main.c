#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, temp;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Before Swapping the value of a=%d and b=%d\n", a, b);

    temp = a;
    a = b;
    b = temp;

    printf("After Swapping the value of a=%d and b=%d\n", a, b);

    return 0;
}
