#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[20] = "How are you";
    int wordCount = 1, i;

    for(i = 0; str[i] != '\0'; i++)
    {
        if(str[i] == ' ')
        {
            wordCount++;
        }
    }

    printf("Total word count is: %d", wordCount);

    return 0;
}
