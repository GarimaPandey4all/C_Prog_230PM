#include <stdio.h>
#include <stdlib.h>

/*
    String Predefined Function

    1. String Length
    2. String Copy
    3. String Concatenate/Joining
    4. String Compare
    5. String Uppercase
    6. String Lowercase

*/

int main()
{
    char str[10];

    printf("Enter your name:");
    //scanf("%s", str);
    gets(str);

    //puts(str);
    printf("Entered String is: %s", str);

    return 0;
}
