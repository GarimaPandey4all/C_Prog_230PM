#include <stdio.h>
#include <stdlib.h>

// 97 - 65 = 32

int main()
{
    char str[10] = "mumbai";
    int i;

//    for(i = 0; str[i] != '\0'; i++)
//    {
//        str[i] = str[i] + 32;
//    }
//
//    printf("Lowercase is: %s\n", str);

    for(i = 0; str[i] != '\0'; i++)
    {
        str[i] = str[i] - 32;
    }

    printf("Uppercase is: %s\n", str);


    return 0;
}
