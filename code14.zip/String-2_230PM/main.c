#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[10];
    char str2[10];

    printf("Enter any string:");
    gets(str);

    printf("Enter any string:");
    gets(str2);

    printf("String's Length is: %d\n", strlen(str));

//    printf("String - 1 copying in String - 2: %s\n", strcpy(str2, str));
//
//    printf("String - 2 is: %s\n", str2);

    //printf("String 1 concate with String 2: %s", strcat(str, str2));

    if(strcmp(str, str2) == 0)
    {
        printf("Strings are Same\n");
    }
    else
    {
        printf("Not Same Strings\n");
    }

    printf("Uppercase is: %s\n", strupr(str));

    printf("Lowercase is: %s\n", strlwr(str2));

    return 0;
}
