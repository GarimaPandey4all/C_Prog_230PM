#include <iostream>

using namespace std;

int main()
{
    int a, b, c;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    try
    {
        if(b == 0)
        {
            throw "Divide by Zero Error";
        }

        c = a / b;
        cout<<"Division is:"<<c<<endl;
    }

//    catch(...)
//    {
//        cout<<"Exception of Division Zero"<<endl;
//    }

    catch(char const* e)
    {
        cout<<e<<endl;
    }

    return 0;
}
