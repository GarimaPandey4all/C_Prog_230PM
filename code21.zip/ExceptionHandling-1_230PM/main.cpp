#include <iostream>

using namespace std;

//Exception: Abnormal Condition / Runtime Error

int main()
{
    cout<<"Exception Handling"<<endl;

    int value = 23;

    try
    {
        if(value == 'S')
            throw 'S';
        if(value == 23)
            throw 23;

        cout<<"Try-Block"<<endl;
    }

    catch(char e)
    {
        cout<<"Exception:"<<e<<endl;
    }


    catch(int e)
    {
        cout<<"Exception:"<<e<<endl;
    }


    return 0;
}
