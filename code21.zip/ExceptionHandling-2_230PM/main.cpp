#include <iostream>

using namespace std;

void Myfunc()
{
    if(4 > 3)
    {
        throw 10;
    }
}


int main()
{
    try
    {
        Myfunc();
    }

    catch(...)
    {
        cout<<"Exception Here"<<endl;
    }

    cout<<"Outside the try-catch block"<<endl;

    return 0;
}
