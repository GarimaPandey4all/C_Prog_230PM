#include <iostream>

using namespace std;

/*
    Polymorphism: Poly(many) and Morphism(forms)

    Person: Student, Son, Brother, Employee, Father etc...

    Polymorphism has two types:

    1. Compile time polymorphism
        a) Function Overloading
        b) Operator Overloading

    2. Runtime Polymorphism
        a) Function Overriding: Virtual Function

*/

class Func_Overloading
{
public:
    void func()
    {
        int a;

        cout<<"Enter value for a:";
        cin>>a;

        cout<<"a is:"<<a<<endl;
    }

    void func(int x, int y)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
    }

    void func(int x, int y, int z)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
        cout<<"z is:"<<z<<endl;
    }
};


int main()
{
    Func_Overloading obj;

    obj.func();
    obj.func(10, 20);
    obj.func(10, 20, 30);

    return 0;
}
