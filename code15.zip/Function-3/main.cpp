#include <stdio.h>
#include <stdlib.h>

//3. Function with arguments and without return type.

void Add(int, int); // Function Declaration// void: no return type

int main()
{
    Add(10, 20); // Actual Arguments

    return 0;
}

//Function Initialization / Definition
void Add(int a, int b) // Formal Arguments / Parameters
{
    printf("Addition is: %d", (a + b));
}
