#include <stdio.h>
#include <stdlib.h>

//4. Function with arguments and with return type.

int Add(int, int); // Function Declaration// void: no return type

int main()
{
    Add(10, 20); // Actual Arguments

    return 0;
}

//Function Initialization / Definition
int Add(int a, int b) // Formal Arguments / Parameters
{
    printf("Addition is: %d", (a + b));

    return 0;
}
