#include <stdio.h>
#include <stdlib.h>

//2. Function without arguments and with return type.

int Add(); // Function Declaration// void: no return type

int main()
{
    //Function Calling
    int result = Add();
    printf("Addition is: %d", result);

    return 0;
}

//Function Initialization / Definition
int Add() // function prototype
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    //printf("Addition is: %d", (a + b));

    return (a + b);
}
