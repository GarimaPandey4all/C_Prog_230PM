#include <stdio.h>
#include <stdlib.h>

/*
    Function: Re-usability : Write once use many times.

    Function has four types:

    1. Function without arguments and without return type.
    2. Function without arguments and with return type.
    3. Function with arguments and without return type.
    4. Function with arguments and with return type.
*/

//1. Function without arguments and without return type.

void Add(); // Function Declaration// void: no return type

int main()
{
    //Function Calling
    Add();
    Add();
    Add();

    return 0;
}

//Function Initialization / Definition
void Add() // function prototype
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d", (a + b));

}
