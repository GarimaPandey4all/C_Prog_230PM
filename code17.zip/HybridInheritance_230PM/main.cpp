#include <iostream>

using namespace std;

class Vehicle
{
public:
    Vehicle()
    {
        cout<<"This is Vehicle Class"<<endl;
    }
};

class FourWheeler
{
public:
    FourWheeler()
    {
        cout<<"This is FourWheeler Class"<<endl;
    }
};

//Multiple
class Car : public Vehicle, public FourWheeler
{
public:
    Car()
    {
        cout<<"This is Car Class"<<endl;
    }
};


class Bus : public Vehicle
{
public:
    Bus()
    {
        cout<<"This is Bus Class"<<endl;
    }
};

int main()
{
    Car obj1;
    Bus obj2;

    return 0;
}
