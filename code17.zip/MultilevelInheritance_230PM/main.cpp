#include <iostream>

using namespace std;

class Parent
{
public:
    int parent;
};

class Child1 : public Parent
{
public:
    int child1;
};


class Child2 : public Child1
{
public:
    int child2;
};


int main()
{
    Child2 obj;

    obj.parent = 20;
    obj.child1 = 40;
    obj.child2 = 60;

    cout<<"Parent is:"<<obj.parent<<endl;
    cout<<"Child-1 is:"<<obj.child1<<endl;
    cout<<"Child-2 is:"<<obj.child2<<endl;

    return 0;
}
