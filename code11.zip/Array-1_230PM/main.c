#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12 // Macros = Pre - Processor Directive

int main()
{
    int days[MONTHS] = {31, 28, 31, 30, 31, 31, 30, 31, 30, 31, 30, 31};

    //printf("First month has %d days", days[0]);

    for(int i = 0; i <MONTHS; i++)
    {
        printf("%d month has %d days\n", i + 1,days[i]);
    }

    return 0;
}
