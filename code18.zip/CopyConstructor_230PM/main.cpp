#include <iostream>

using namespace std;

class CC
{
public:
    int a;

    CC(int x) // Parameterized Constructor
    {
        a = x; // 10
    }

    CC(CC &t) // Copy Constructor
    {
        a = t.a; // 10
    }


};

int main()
{
    CC obj(10);
    CC obj2(obj);

    cout<<"A of obj2 is:"<<obj2.a<<endl;

    return 0;
}
