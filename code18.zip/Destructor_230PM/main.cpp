#include <iostream>

using namespace std;

//Destructor: Delete the object, it is called automatically

class HelloWorld
{
public:
    HelloWorld()
    {
        cout<<"Constructor"<<endl;
    }

    //Destructor
    ~HelloWorld()
    {
        cout<<"Destructor"<<endl;
    }

    void display()
    {
        cout<<"Hello World"<<endl;
    }
};

int main()
{
    HelloWorld obj;
    obj.display();

    return 0;
}
