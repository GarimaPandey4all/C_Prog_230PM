#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter any number:");
    scanf("%d", &number);

    ((number % 2) == 0) ? printf("Number is Even") : printf("Number is Odd");

    return 0;
}
