#include <stdio.h>
#include <stdlib.h>

/*
    Ternary / Conditional Operator

    Ternary : 3

    Syntax: (? :)

    (Condition) ? (True) : (False)
    (Expression-1) ? (Expression-2) : (Expression-3)
*/


int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    (a > b) ? printf("A is Greater") : printf("B is Greater");

    return 0;
}
