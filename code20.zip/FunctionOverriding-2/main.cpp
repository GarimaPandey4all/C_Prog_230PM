#include <iostream>

using namespace std;

class Shape
{
public:
    void shape()
    {
        cout<<"Shape of parent class"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Shape of child class"<<endl;
        Shape::shape();
    }
};


int main()
{
    Circle obj;

    obj.shape();

    return 0;
}
