#include <iostream>

using namespace std;

class ThisKeyword
{
    int a, b;

public:
    void setData(int a, int b)
    {
        this->a = a;
        this->b = b;
    }

    void getData()
    {
        cout<<a<<"  "<<b<<endl;
    }
};

int main()
{
    ThisKeyword obj;
    obj.setData(10, 20);
    obj.getData();

    return 0;
}
