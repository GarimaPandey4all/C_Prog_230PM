#include <iostream>

using namespace std;

namespace first
{
    int var = 200;
}

namespace second
{
    int var = 500;

    void showData()
    {
        cout<<"Hello World"<<endl;
    }
}

//Global Variable
    //int var = 200;

int main()
{
    //Local Variable
    int var = 100;

    cout << var << endl;

    cout<< first::var<<endl;

    cout<< second::var<<endl;

    second::showData();

    return 0;
}
