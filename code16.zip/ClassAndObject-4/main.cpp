#include <iostream>

using namespace std;

class Basic
{
public:

    int a, b;

    void display()
    {
        cout<<a<<"  "<<b;
    }
};

int main()
{
    Basic obj;

    obj.a = 30;
    obj.b = 50;

    obj.display();

    return 0;
}
