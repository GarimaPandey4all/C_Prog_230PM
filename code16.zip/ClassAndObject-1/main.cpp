#include <iostream> // iostream: Input / Output Stream(flow of data)

//using namespace std; // namespace: collection of classes

class HelloWorld
{
    /*
        Class :
        data member (variables)
        member function (functions)

        Access Modifier/Specifier

        1. Public
        2. Private (By Default)
        3. Protected
    */

public:
    void showData()
    {
        std::cout<<"Hello World"<<std::endl; // cout: Print output on output screen
        //<< - Operator or put to operator
        // :: - Scope Resolution Operator

        //cin>> // cin: Read User Input // >> - Operator or get from operator
    }

};


int main()
{
    HelloWorld obj;

    obj.showData();

    return 0;
}
