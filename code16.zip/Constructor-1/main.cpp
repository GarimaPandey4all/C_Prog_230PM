#include <iostream>

using namespace std;

/*
    Constructor: It is a special type of function, because the name
    of constructor and name of class both are same.

    It is used to initialize the instance variables.

    When class's object created then the constructor called itself.

*/

class Basic
{

    int a, b;

 public:
    Basic(int x, int y) // Parameterized Constructor
    {
        a = x;
        b = y;
    }

    void display()
    {
        cout<<a<<"  "<<b<<endl;
    }
};

int main()
{
    Basic obj(10, 20);

    obj.display();

    return 0;
}
