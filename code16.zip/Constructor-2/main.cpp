#include <iostream>

using namespace std;

class Basic
{
public:
    Basic() // Default Constructor
    {
        cout<<"Hello World";
    }
};

int main()
{
    Basic obj;

    return 0;
}
