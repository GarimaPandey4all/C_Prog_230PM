#include <iostream>

using namespace std;

/*
    Abstraction: provide us the data - security

    don't provide internal information to your customer,
    only provide essential info to them.
*/

class Abstraction
{
private:

    int a, b;

public:
    void getData(int x, int y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<"Modulus:"<<(a % b)<<endl;
    }

};


int main()
{
    Abstraction obj;

    obj.getData(20, 60);
    obj.showData();

    return 0;
}
