#include <iostream>

using namespace std;

class Add
{
public:

    int a, b; // instance variable

    void getData(int x, int y)
    {
        a = x; // instance variable = local variable
        b = y;
    }

    void showData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
    }
};

int main()
{
    Add obj;

    obj.getData(10, 20);
    obj.showData();

    return 0;
}
