#include <iostream>

using namespace std;

class Basic
{
public:

    Basic();
};

Basic :: Basic()
{
    cout<<"Hello World";
}

int main()
{
    Basic obj;

    return 0;
}
