#include <iostream>

using namespace std;

class Basic
{
public:
    void display();
};

void Basic :: display()
{
    cout<<"Hello World";
}

int main()
{
    Basic obj;
    obj.display();

    return 0;
}
