#include <iostream>

using namespace std;

class Calculator
{
public:
    int a, b;

    void getData()
    {
        cout<<"Enter value for a and b:";
        cin>>a>>b;
    }

    void showData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
        cout<<"Subtraction is:"<<(a - b)<<endl;
        cout<<"Multiplication is:"<<(a * b)<<endl;
        cout<<"Division is:"<<(a / b)<<endl;
    }
};


int main()
{
    Calculator obj;
    Calculator obj2;

    obj.getData();
    obj.showData();

    obj2.getData();
    obj2.showData();

    return 0;
}
