#include <iostream>

using namespace std;

class Encapsulation // Encapsulation: Example Class
{
public:
    int a, b;

    void getData()
    {
        cout<<"Enter value for a and b:";
        cin>>a>>b;
    }

    void showData()
    {
        cout<<"A is:"<<a<<endl;
        cout<<"B is:"<<b<<endl;
    }

};

int main()
{
    Encapsulation obj;
    obj.getData();
    obj.showData();

    return 0;
}
