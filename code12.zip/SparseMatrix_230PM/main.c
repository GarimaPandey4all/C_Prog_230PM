#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, matrix[5][5], rows, cols, totalCount;

    printf("Enter number of rows:");
    scanf("%d", &rows);

    printf("Enter number of columns:");
    scanf("%d", &cols);

    printf("Enter any value in matrix:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("Values in matrix are:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            if(matrix[i][j] == 0)
            {
                totalCount++;
            }
        }
    }

    if(totalCount > (rows * cols)/2)
    {
        printf("Sparse Matrix");
    }
    else
    {
        printf("Not Sparse Matrix");
    }

    return 0;
}
