#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("AND Logical: %d\n", (a == b && a > 30)); // 0 && 0 = 0
    printf("OR Logical: %d\n", (a == b || a > 9));  // 0 || 1 = 1
    printf("AND Logical: %d\n", !(a == b && a > 30)); // 0 = 1

    return 0;
}
