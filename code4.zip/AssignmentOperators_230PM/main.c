#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 40; // assignment operator
    int sum = 0;

    sum += a;//sum = sum + a;

    printf("Sum is: %d", sum);

    return 0;
}
